// Copyright 2026 ihb2032 <hebome@foxmail.com>
// SPDX-License-Identifier: BSD-3-Clause

#ifndef LAYER_THRESHOLD_RISCV_H
#define LAYER_THRESHOLD_RISCV_H

#include "threshold.h"

namespace ncnn {

class Threshold_riscv : public Threshold
{
public:
    Threshold_riscv();

    virtual int forward_inplace(Mat& bottom_top_blob, const Option& opt) const;

protected:
#if NCNN_ZFH
    int forward_inplace_fp16s(Mat& bottom_top_blob, const Option& opt) const;
#endif
};

} // namespace ncnn

#endif // LAYER_THRESHOLD_RISCV_H
